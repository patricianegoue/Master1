import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'inscription',
  templateUrl: './inscription.component.html',
  styleUrls: ['./inscription.component.css']
})
export class InscriptionComponent implements OnInit {


  constructor(private router: Router) { }

  username = '';
  password = '';
  login = '';
  age = '';
  taille = '';





  Inscription() {
    if (this.username != '' && this.password != '' && this.login != '' && this.age != '' && this.taille != '') {
      let user = {
        username: this.username,
        password: this.password,
        login: this.login,
        age: this.age,
        taille: this.taille,
      };

      console.log('Utilisateur creer ====================================');
      console.log(user);
      console.log('====================================');
      localStorage.setItem("user", JSON.stringify(user));
      this.username = '';
      this.login = '';
      this.password = '';
      this.age = '';
      this.taille = '';
      alert("Inscription reussie");
    } else {
      alert("tous les champs sont obligatoires");
    }
  }

  ngOnInit(): void {
  }

}
