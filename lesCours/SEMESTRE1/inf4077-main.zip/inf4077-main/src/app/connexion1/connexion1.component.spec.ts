import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Connexion1Component } from './connexion1.component';

describe('Connexion1Component', () => {
  let component: Connexion1Component;
  let fixture: ComponentFixture<Connexion1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Connexion1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Connexion1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
