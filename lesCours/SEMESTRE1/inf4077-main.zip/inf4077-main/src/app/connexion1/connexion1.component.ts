import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'connexion1',
  templateUrl: './connexion1.component.html',
  styleUrls: ['./connexion1.component.css']
})
export class Connexion1Component implements OnInit {


  constructor(private router: Router) { }

  username = '';
  password = '';

  Connexion() {
    if (this.username != '' && this.password != '') {
      let user = localStorage.getItem("user");
      if (user == null) {
        alert("compte inexistant");
      }
      else {
        let userJson = JSON.parse(user);
        console.log('Utilisateur en local ====================================');
        console.log(userJson);
        console.log('====================================');
        if (this.username == userJson.login && this.password == userJson.password) {
          this.router.navigateByUrl("home");
        } else {
          alert("Nom d'utilisateur ou mot de passe incorrect.");
        }

      }
    } else {
      alert("tous les champs sont obligatoires");
    }
  }

  ngOnInit(): void {
  }

}
