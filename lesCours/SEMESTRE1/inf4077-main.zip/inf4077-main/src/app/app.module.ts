import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ToastrModule } from 'ngx-toastr';

import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';

import { AppComponent } from './app.component';

import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { LoginComponent } from './login/login.component';
import { Connexion1Component } from './connexion1/connexion1.component';
import { InscriptionComponent } from './inscription/inscription.component';
import { StatutComponent } from './statut/statut.component';
import { ImcComponent } from './imc/imc.component';
import { UpdateProfilComponent } from './update-profil/update-profil.component';



@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    NgbModule,
    ToastrModule.forRoot()
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    LoginComponent,
    Connexion1Component,
    InscriptionComponent,
    ImcComponent,
    StatutComponent,
    UpdateProfilComponent,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
