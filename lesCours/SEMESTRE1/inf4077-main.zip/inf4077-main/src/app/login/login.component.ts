import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  constructor(private router: Router) { }

  repas = {
    quantite: 0,
    nom: "",
    date: new Date(),
  };
  repasList: any[] = [];

  /**
   * Ajouter un repas dans le localStorage
   */
  enregistrer() {
    if (this.repas.quantite > 0 && this.repas.nom != '') {
      this.repasList.push(this.repas);
      localStorage.setItem("repasList", JSON.stringify(this.repasList));
      alert("Repas ajouté");
    } else {
      alert("tous les champs sont obligatoires");
    }
  }

  /**
   * Retirer un repas de la liste
   * @param r
   * @param index
   */
  supprimer(r: any, index: number) {
    console.log(' Repas a retirer ====================================');
    console.log("repas --------------------");
    console.log(r);
    console.log("index --------------------");
    console.log(index);
    console.log('====================================');

    // retirer le repas r de la liste repasList en utilisant index
    this.repasList.splice(index, 1);
    localStorage.setItem("repasList", JSON.stringify(this.repasList
      .filter((e: any) => e !== r)));
  }

  /**
   * Recuperer la liste de tous les repas consommer
   */
  getRepasList() {

    // on recupere la liste de tous les repas
    let repasListStr = localStorage.getItem("repasList");
    if (repasListStr != null) this.repasList = JSON.parse(repasListStr);

    console.log('Liste des repas ====================================');
    console.log(this.repasList);
    console.log('====================================');
  }

  ngOnInit(): void {
    this.getRepasList();
  }

}
