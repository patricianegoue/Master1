import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'imc',
  templateUrl: './imc.component.html',
  styleUrls: ['./imc.component.css']
})
export class ImcComponent implements OnInit {

  constructor(private router: Router) { }

  taille = 0;
  poids = 0;
  imc = 0;

  calculer() {
    console.log(' Form data ====================================');
    console.log("Taille: " + this.taille);
    console.log("Poids: " + this.poids);
    console.log('====================================');
    if (this.taille > 0 && this.poids > 0) {
      this.imc = this.poids / (this.taille * this.taille);
    } else {
      alert("Formulaire invalide");
    }
  }

  ngOnInit(): void {
  }

}
