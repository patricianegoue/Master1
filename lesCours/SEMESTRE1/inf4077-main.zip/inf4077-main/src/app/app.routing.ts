import { NgModule } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';

import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { LoginComponent } from './login/login.component';
import { Connexion1Component } from './connexion1/connexion1.component';
import { InscriptionComponent } from './inscription/inscription.component';
import { ImcComponent } from './imc/imc.component';

const routes: Routes = [
  {
    path: 'home',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  },
  {
    path: '', component: Connexion1Component
  },

  {
    path: 'inscription', component: InscriptionComponent
  },


  {
    path: '',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () => import('./layouts/admin-layout/admin-layout.module').then(x => x.AdminLayoutModule)
      },
    ]
  },
  {
    path: '**',
    redirectTo: 'dashboard'
  },
  {
    path: '/login',
    component: LoginComponent
  },
];

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  exports: [
  ],
})
export class AppRoutingModule { }
