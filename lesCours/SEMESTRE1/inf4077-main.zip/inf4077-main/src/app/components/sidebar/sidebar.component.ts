import { Component, OnInit } from '@angular/core';

declare interface RouteInfo {
  path: string;
  title: string;
  icon: string;
  class: string;
}
export const ROUTES: RouteInfo[] = [
  { path: '/dashboard', title: 'Dashboard', icon: 'design_app', class: '' },
  { path: '/add-food', title: 'Ajouter un repas', icon: 'design-app', class: ''},
  { path: '/add-info', title: 'Ajouter les informations', icon: 'design-app', class: ''},
  { path: '/statut', title: 'Statut de sante', icon: 'design-app', class: ''},
  { path: '/profil', title: 'Modification du profil', icon: 'design-app', class: ''},  
  { path: '/imc', title: 'Indice masse corporelle', icon: 'design-app', class: ''},  

];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  menuItems: any[];

  constructor() { }

  ngOnInit() {
    this.menuItems = ROUTES.filter(menuItem => menuItem);
  }
  isMobileMenu() {
    if (window.innerWidth > 991) {
      return false;
    }
    return true;
  }; 
}
