import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'update-profil',
  templateUrl: './update-profil.component.html',
  styleUrls: ['./update-profil.component.css']
})
export class UpdateProfilComponent implements OnInit {


  constructor(private router: Router) { }

  user = {
    username: "",
    password: "",
    login: "",
    age: 0,
    taille: 0,
  };

  modifier() {
    if (this.user.username != '' && this.user.age > 0 && this.user.taille > 0) {

      console.log('Utilisateur modifier ====================================');
      console.log(this.user);
      console.log('====================================');

      localStorage.setItem("user", JSON.stringify(this.user));

      alert("Profil mis a jour");
    } else {
      alert("tous les champs sont obligatoires");
    }
  }

  ngOnInit(): void {
    let user = localStorage.getItem("user");
    this.user = JSON.parse(user);
    console.log('Utilisateur en local ====================================');
    console.log(this.user);
    console.log('====================================');
  }

}
