import { Component, OnInit } from '@angular/core';
import * as Chartist from 'chartist';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public lineBigDashboardChartType;
  public gradientStroke;
  public chartColor;
  public canvas: any;
  public ctx;
  public gradientFill;
  public lineBigDashboardChartData: Array<any>;
  public lineBigDashboardChartOptions: any;
  public lineBigDashboardChartLabels: Array<any>;
  public lineBigDashboardChartColors: Array<any>

  public gradientChartOptionsConfiguration: any;
  public gradientChartOptionsConfigurationWithNumbersAndGrid: any;

  public lineChartType;
  public lineChartData: Array<any>;
  public lineChartOptions: any;
  public lineChartLabels: Array<any>;
  public lineChartColors: Array<any>

  public lineChartWithNumbersAndGridType;
  public lineChartWithNumbersAndGridData: Array<any>;
  public lineChartWithNumbersAndGridOptions: any;
  public lineChartWithNumbersAndGridLabels: Array<any>;
  public lineChartWithNumbersAndGridColors: Array<any>

  public lineChartGradientsNumbersType;
  public lineChartGradientsNumbersData: Array<any>;
  public lineChartGradientsNumbersOptions: any;
  public lineChartGradientsNumbersLabels: Array<any>;
  public lineChartGradientsNumbersColors: Array<any>

  repasList: any[] = [];
  data = {
    lun: 0,
    mar: 0,
    mer: 0,
    jeu: 0,
    ven: 0,
    sam: 0,
    dim: 0
  };
  days = [
    'Dim',
    'Lun',
    'Mar',
    'Mer',
    'Jeu',
    'Ven',
    'Sam',
  ]
  consommationDays = [];

  // events ==============================================
  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }

  public hexToRGB(hex, alpha) {
    var r = parseInt(hex.slice(1, 3), 16),
      g = parseInt(hex.slice(3, 5), 16),
      b = parseInt(hex.slice(5, 7), 16);

    if (alpha) {
      return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
    } else {
      return "rgb(" + r + ", " + g + ", " + b + ")";
    }
  }
  constructor() { }

  /**
   * Recuperer la liste de tous les repas consommer cette semaine
   */
  getRepasList() {

    // Recuperer le premier et dernier jour de la semaine en cour
    const today = new Date();

    // ✅ Get the first day of the current week (Sunday)
    const firstDay = new Date(
      today.setDate(today.getDate() - today.getDay()),
    );

    // ✅ Get the last day of the current week (Saturday)
    const lastDay = new Date(
      today.setDate(today.getDate() - today.getDay() + 6),
    );

    console.log("1er jour de la semaine: " + firstDay);
    console.log("Dernier jour de la semaine: " + lastDay);


    let repasListStr = localStorage.getItem("repasList");
    if (repasListStr != null) this.repasList = JSON.parse(repasListStr);

    // puis on filtre sa en fonction de firstDay et lastDay
    this.repasList = this.repasList.filter((x: any) => x.date >=
      firstDay.toISOString().substring(0, 10) &&
      x.date <= lastDay.toISOString().substring(0, 10
      ));

    // pour chaque jour de la semaine, on recupere la consommation en Kcal
    this.data.dim = this.getKcalOfDay(firstDay, this.repasList); // dimanche
    this.data.lun = this.getKcalOfDay(new Date(
      today.setDate(today.getDate() - today.getDay() + 1),
    ), this.repasList); // lundi
    this.data.mar = this.getKcalOfDay(new Date(
      today.setDate(today.getDate() - today.getDay() + 2),
    ), this.repasList); // mardi
    this.data.mer = this.getKcalOfDay(new Date(
      today.setDate(today.getDate() - today.getDay() + 3),
    ), this.repasList); // mercredi
    this.data.jeu = this.getKcalOfDay(new Date(
      today.setDate(today.getDate() - today.getDay() + 4),
    ), this.repasList); // jeudi
    this.data.ven = this.getKcalOfDay(new Date(
      today.setDate(today.getDate() - today.getDay() + 5),
    ), this.repasList); // vendredi
    this.data.sam = this.getKcalOfDay(lastDay, this.repasList); // Samedi

    console.log('Liste des repas consommer cette semaine ====================================');
    console.log(this.repasList);
    console.log('====================================');

    console.log('Consomation de la semaine ====================================');
    console.log(this.data);
    console.log('====================================');
  }

  /**
   * Fait la somme des Kcal consommer en jour d dans une liste repasList
   * @param d
   * @param repasList
   */
  getKcalOfDay(d: Date, repasList: any[]) {
    var sum = 0;
    for (let i in repasList) {
      let r = repasList[i];
      this.consommationDays.push(new Date(r.date).getUTCDay());
      if (r.date.substring(0, 10) === d.toISOString().substring(0, 10)) sum += parseInt(r.quantite);
    }
    return sum;
  }

  /**
   * Retourne le tablea de consommation en kcl
   */
  getConsommationOfWeek() {

  }

  ngOnInit() {
    // on recupere les donnees
    this.getRepasList();

    // on initialise le graph
    this.chartColor = "#FFFFFF";
    this.canvas = document.getElementById("bigDashboardChart");
    this.ctx = this.canvas.getContext("2d");

    this.gradientStroke = this.ctx.createLinearGradient(500, 0, 100, 0);
    this.gradientStroke.addColorStop(0, '#80b6f4');
    this.gradientStroke.addColorStop(1, this.chartColor);

    this.gradientFill = this.ctx.createLinearGradient(0, 200, 0, 50);
    this.gradientFill.addColorStop(0, "rgba(128, 182, 244, 0)");
    this.gradientFill.addColorStop(1, "rgba(255, 255, 255, 0.24)");

    this.lineBigDashboardChartData = [
      {
        label: "Data",

        pointBorderWidth: 1,
        pointHoverRadius: 7,
        pointHoverBorderWidth: 2,
        pointRadius: 5,
        fill: true,

        borderWidth: 2,
        data: [this.data.dim, this.data.lun, this.data.mar, this.data.mer, this.data.jeu, this.data.ven, this.data.sam]
      }
    ];
    this.lineBigDashboardChartColors = [
      {
        backgroundColor: this.gradientFill,
        borderColor: this.chartColor,
        pointBorderColor: this.chartColor,
        pointBackgroundColor: "#2c2c2c",
        pointHoverBackgroundColor: "#2c2c2c",
        pointHoverBorderColor: this.chartColor,
      }
    ];
    this.lineBigDashboardChartLabels = ["DIM", "LUN", "MAR", "MER", "JEU", "VEN", "SAM"];
    this.lineBigDashboardChartOptions = {

      layout: {
        padding: {
          left: 20,
          right: 20,
          top: 0,
          bottom: 0
        }
      },
      maintainAspectRatio: false,
      tooltips: {
        backgroundColor: '#fff',
        titleFontColor: '#333',
        bodyFontColor: '#666',
        bodySpacing: 4,
        xPadding: 12,
        mode: "nearest",
        intersect: 0,
        position: "nearest"
      },
      legend: {
        position: "bottom",
        fillStyle: "#FFF",
        display: false
      },
      scales: {
        yAxes: [{
          ticks: {
            fontColor: "rgba(255,255,255,0.4)",
            fontStyle: "bold",
            beginAtZero: true,
            maxTicksLimit: 5,
            padding: 10
          },
          gridLines: {
            drawTicks: true,
            drawBorder: false,
            display: true,
            color: "rgba(255,255,255,0.1)",
            zeroLineColor: "transparent"
          }

        }],
        xAxes: [{
          gridLines: {
            zeroLineColor: "transparent",
            display: false,

          },
          ticks: {
            padding: 10,
            fontColor: "rgba(255,255,255,0.4)",
            fontStyle: "bold"
          }
        }]
      }
    };

    this.lineBigDashboardChartType = 'line';
  }


}
