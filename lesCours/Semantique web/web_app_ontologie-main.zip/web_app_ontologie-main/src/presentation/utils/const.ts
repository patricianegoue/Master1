export const STRING_ROUTE_HOME = '/';
export const STRING_ROUTE_OUT = '/out';
export const STRING_ROUTE_LOGING = '/login';
export const ENDPOINT_URI = 'http://localhost:3030/food_ontologie/query';
export const ENDPOINT_URI_ADD = 'http://localhost:3030/food_ontologie/update'
export const STRING_ROUTE_QUERIES = '/queries';
export const STRING_ROUTE_ADD = '/add';
export const QUERY_ONE = `PREFIX owl: <http://www.w3.org/2002/07/owl#>
                          PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                          PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                          PREFIX food: <http://www.semanticweb.org/dave/ontologies/2024/3/untitled-ontology-14#>
                          SELECT ?class ?subclass ?instance
                          WHERE {
                           ?class rdf:type owl:Class .
                           ?subclass rdfs:subClassOf ?class .
                           ?instance rdf:type ?subclass
                          }`;
export const QUERY_TWO = `PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                          PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                          PREFIX food: <http://www.semanticweb.org/dave/ontologies/2024/3/untitled-ontology-14#>
                          SELECT ?nom
                          WHERE {
                            ?individu food:name ?nom .
                          }ORDER BY ASC(?nom)`;
export const QUERY_THREE = `PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                          PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                          PREFIX food: <http://www.semanticweb.org/dave/ontologies/2024/3/untitled-ontology-14#>
                          SELECT ?nom
                          WHERE {
                            ?individu food:name ?nom .
                          }ORDER BY DESC(?nom)`;

