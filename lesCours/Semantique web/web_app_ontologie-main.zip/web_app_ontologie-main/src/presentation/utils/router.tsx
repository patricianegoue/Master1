import {createBrowserRouter} from "react-router-dom";
import Connexion from "../pages/Connexion.tsx";
import Queries from "../pages/Queries.tsx";
import Add from "../pages/Add.tsx";
import Home from "../pages/home.tsx";
import HomeContent from "../pages/HomeContent.tsx";
import MyComponent from "../pages/MyComponent"
import {STRING_ROUTE_HOME, STRING_ROUTE_LOGING, STRING_ROUTE_OUT,STRING_ROUTE_QUERIES,STRING_ROUTE_ADD} from "./const.ts";


const router = createBrowserRouter([
    {
        path: STRING_ROUTE_LOGING,
        element: <Connexion/>,
    },
    {
        path: STRING_ROUTE_HOME,
        element: <Home/>,
        children: [
            {
                path: '',
                element: <HomeContent/>
            },
            {
                path: STRING_ROUTE_QUERIES,
                element: <Queries/>
            },
            {
                path: STRING_ROUTE_ADD,
                element: <Add/>
            }
        ]
    }
]);

export default router;