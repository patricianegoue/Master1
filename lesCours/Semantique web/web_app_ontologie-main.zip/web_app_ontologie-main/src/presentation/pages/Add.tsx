import React, { useState } from 'react';
import {ENDPOINT_URI_ADD} from "../utils/const.ts"
import {Modal} from "../components/modal.tsx"
import Dropdown from "../components/Dropdown.tsx"
function Add() {
   const [formData, setFormData] = useState<{ [key: string]: string }>({
       name: "",
       imageUri: ""
     });
   const [loading, setLoading] = useState(false);
   const [responseData, setResponseData] = useState(null);
   const [errors, setErrors] = useState<{ [key: string]: string }>({});
   const [globalError, setGlobalError] = useState("");
   const [showModal, setShowModal] = useState(false);
   const [selectedItem, setSelectedItem] = useState("Food");
   const handleDropdownChange = (item) => {
       setSelectedItem(item);
     };
     const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
       setFormData({ ...formData, [e.target.name]: e.target.value });
     };

      const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
         e.preventDefault();
         setLoading(true);
         const newErrors: { [key: string]: string } = {};
         Object.keys(formData).forEach((key) => {
           if (!formData[key]) {
             newErrors[key] = "Ce champ est requis";
           }
         });
         if (selectedItem === "") {
               setGlobalError("Veuillez choisir une option.");
               return;
             }
         if (Object.keys(newErrors).length > 0) {
           setErrors(newErrors);
           setLoading(false)
           return;
         }
         console.log(formData.name, formData.imageUri, selectedItem)
         const query =   `PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                          PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                          PREFIX food: <http://www.semanticweb.org/dave/ontologies/2024/3/untitled-ontology-14#>
                          INSERT DATA
                          {
                            food:${formData.name} rdf:type food:${selectedItem} ;
                                    food:name '${formData.name}';
                                    food:image '${formData.imageUri}'.
                          }`

         try {
           const response = await fetch(`${ENDPOINT_URI_ADD}?update=${encodeURIComponent(query)}`, {
               method: "POST",
               headers: {
                       "Content-Type": "application/x-www-form-urlencoded"
                     },
           });
           const data = await response.text();
           console.log(data)
           setResponseData(data);
           setShowModal(true)
         } catch (error) {
           console.error('Erreur lors de la requête :', error);
           setGlobalError("Une erreur s'est produite lors de l'envoi du formulaire.")
         }
         setLoading(false)
         setFormData({});
         setErrors({});
       };

     return (
       <div className="max-w-md mx-auto">
       <h1 className="flex justify-center ext-center text-3xl text-green-950 mb-7 mt-5 font-bold max-sm:max-lg:hidden" >Add Food</h1>
       {globalError && <p className="mt-2 text-sm text-red-600">{globalError}</p>}
         <form onSubmit={handleSubmit} className="space-y-4">
           <div>
             <label htmlFor="name" className="block font-medium">
               Nom:
             </label>
             <input
               type="text"
               id="name"
               name="name"
               value={formData.name}
               placeholder="Enter name's food..."
               onChange={handleChange}
               className="mt-1 block w-full h-10 px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
             />
             {errors.name && (
               <p className="mt-2 text-sm text-red-600">{errors.name}</p>
             )}
           </div>
           <div>
                <label htmlFor="imageUri" className="block font-medium">
                  imageUri:
                </label>
                <input
                  type="text"
                  id="imageUri"
                  name="imageUri"
                  placeholder="Enter imageUri's food..."
                  value={formData.imageUri}
                  onChange={handleChange}
                  className="mt-1 block w-full h-10 px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                />
                {errors.imageUri && (
                  <p className="mt-2 text-sm text-red-600">{errors.imageUri}</p>
                )}
              </div>
           <div>
           <div>
                 <label className="block font-medium mx-2 mb-4">Choisir l'élément à ajouter:</label>
                 <Dropdown
                   data={["Food", "FoodIngredient", "FoodComponent", "Dish"]}
                   handleChange={handleDropdownChange}
                 />
               </div>
             <button
               type="submit"
               className="inline-flex mt-4 items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
               disabled={loading}
             >
                {loading ? 'Envoi en cours...' : 'Ajouter'}
             </button>
           </div>
         </form>

         {showModal&&<Modal onClick={() => setShowModal(false)} isBig={true}>
           <p>Ajouté avec succès !</p>
         </Modal>}

       </div>
     );
}
export default Add




