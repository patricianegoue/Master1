import React, { useState, useEffect } from 'react';
import * as RDF from 'rdf lib';

interface Data {
  // Définissez ici la structure de vos données récupérées
}

const MyComponent: React.FC = () => {
  const [results, setResults] = useState<Data[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const endpointUri = 'http://localhost:3030/food_ontologie/query';
    const query = `
      PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
      PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
      PREFIX foaf: <http://xmlns.com/foaf/0.1/>

      SELECT ?subject ?property ?value
      WHERE {
        ?subject ?property ?value.
      }
      LIMIT 10
    `;

    setLoading(true);

    // Effectuer la requête SPARQL à l'endpoint Jena
    fetch(`${endpointUri}?query=${encodeURIComponent(query)}`, {
      headers: {
        Accept: 'application/sparql-results+json',
      },
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then(data => {
        const results: Data[] = [];
        data.results.bindings.forEach((binding: any) => {
          const result: Data = {
            subject: binding.subject.value,
            property: binding.property.value,
            value: binding.value.value,
          };
          results.push(result);
        });
        setResults(results);
        setLoading(false);
        setError(null);
      })
      .catch(error => {
        setError('Error fetching data');
        setLoading(false);
      });
  }, []);

  return (
    <div>
      <h2>Résultats de la requête SPARQL sur Jena</h2>
      {loading && <p>Loading...</p>}
      {error && <p>Error: {error}</p>}
      <table>
        <thead>
          <tr>
            <th>Sujet</th>
            <th>Propriété</th>
            <th>Valeur</th>
          </tr>
        </thead>
        <tbody>
          {results.map((result, index) => (
            <tr key={index}>
              <td>{result.subject}</td>
              <td>{result.property}</td>
              <td>{result.value}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MyComponent;