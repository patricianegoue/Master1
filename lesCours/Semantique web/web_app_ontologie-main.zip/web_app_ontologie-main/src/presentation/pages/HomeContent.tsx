import * as RDF from 'rdf lib';
import React, { useState } from 'react';
import {QUERY_ONE} from "../utils/const.ts";
import {QUERY_TWO} from "../utils/const.ts";
import {QUERY_THREE} from "../utils/const.ts";
import {ENDPOINT_URI} from "../utils/const.ts"
import Dropdown from "../components/Dropdown.tsx"
import SPARQLResultsTable from "../components/SPARQLResultsTable.tsx"

function HomeContent() {
        const [selectedOption, setSelectedOption] = useState('');
        const [responseData, setResponseData] = useState(null);
        const [loading, setLoading] = useState(false);
        const options = [
                { name: 'Choisissez une requête', requestBody: {key: ''} },
                { name: 'Classes and Instances', requestBody: { key: QUERY_ONE } },
                { name: 'Name of all food (ASC)', requestBody: { key: QUERY_TWO} },
                { name: 'Name of all food (DESC)', requestBody: { key: QUERY_THREE} }
            ];
        const handleDropdownChange = async (selected) => {
                setSelectedOption(selected);
                setLoading(true);
                try {
                    const selectedOptionObj = options.find(option => option.name === selected);
                    if (selectedOptionObj) {
                        const response = await fetch(`${ENDPOINT_URI}?query=${encodeURIComponent(selectedOptionObj.requestBody.key)}`, {
                            headers: {
                                    Accept: 'application/sparql-results+json',
                                  },
                        });
                        const data = await response.json();
                        setResponseData(data);
                    }
                } catch (error) {
                    console.error('Erreur lors de la requête :', error);
                }
                setLoading(false);
        };
    return (
        <div>
            <h1 className="flex justify-center ext-center text-3xl text-green-950 mb-7 mt-5 font-bold max-sm:max-lg:hidden">Listes des requêtes</h1>
            <Dropdown data={options.map(option => option.name)} handleChange={handleDropdownChange} />
            {loading && <p>Chargement en cours...</p>}
            {console.log(responseData)}
            <SPARQLResultsTable results={responseData} itemsPerPage={10}/>
        </div>
    )
}
export default HomeContent




