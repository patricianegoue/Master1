import React, { useState } from 'react';
import QueryForm from "../components/QueryForm.tsx"
import * as RDF from 'rdf lib';
import {ENDPOINT_URI} from "../utils/const.ts"
import SPARQLResultsTable from "../components/SPARQLResultsTable.tsx"


const Queries: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [responseData, setResponseData] = useState(null);
  const handleSubmitQuery = async (query: string) => {
      setLoading(true);
      try {
          if (query) {
              const response = await fetch(`${ENDPOINT_URI}?query=${encodeURIComponent(query)}`, {
                  headers: {
                          Accept: 'application/sparql-results+json',
                        },
              });
              const data = await response.json();
              console.log(data)
              setResponseData(data);
          }
      } catch (error) {
          console.error('Erreur lors de la requête :', error);
      }
      setLoading(false);
    console.log('Query submitted:', query);
  };

  return (
    <div>
      <h1 className="flex justify-center ext-center text-3xl text-green-950 mb-7 mt-5 font-bold max-sm:max-lg:hidden" >SPARQL Query</h1>
      <QueryForm onSubmit={handleSubmitQuery} />
      {loading && <p>Chargement en cours...</p>}
      <SPARQLResultsTable results={responseData} itemsPerPage={5} />
    </div>
  );
};

export default Queries;


