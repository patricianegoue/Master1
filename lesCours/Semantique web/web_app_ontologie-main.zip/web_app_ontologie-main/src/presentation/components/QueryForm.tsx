import React, { useState } from 'react';
interface QueryFormProps {
  onSubmit: (query: string) => void;
}

const QueryForm: React.FC<QueryFormProps> = ({ onSubmit }) => {
  const [query, setQuery] = useState('');
  const [error, setError] = useState('');
  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!query.trim()) {
      setError('Please enter a query.');
      return;
    }
    onSubmit(query);
    setError('');
  };
  const handleChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setQuery(event.target.value);
    setError(''); // Clear error when input changes
  };

  return (
    <form onSubmit={handleSubmit} className="mx-auto ml-5 mr-5">
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="query">
          Query:
        </label>
        <textarea
          className={`language-sparql resize-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline ${error && 'border-red-500'}`}
          id="query"
          value={query}
          onChange={handleChange}
          placeholder="Enter your SPARQL query here..."
          rows={10}
        />
        {error && <p className="text-red-500 text-xs italic">{error}</p>}
      </div>
      <button
        type="submit"
        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
      >
        Submit
      </button>
    </form>
  );
};

export default QueryForm;