import React, { useState }  from 'react';

function extractColumns(results) {
    if (results && results.head && results.head.vars) {
        return results.head.vars;
    }
    return [];
}

function extractData(results, columns) {
    const data = [];
    if (results && results.results && results.results.bindings) {
        results.results.bindings.forEach((binding) => {
            const row = {};
            columns.forEach((column) => {
                if (binding[column] && binding[column].value) {
                    row[column] = binding[column].value;
                }
            });
            data.push(row);
        });
    }
    return data;
}

function SPARQLResultsTable({ results , itemsPerPage}) {
    const [currentPage, setCurrentPage] = useState(1);
    if (!results || results == null || results.length === 0 || results && results.results && results.results.bindings.length===0) {
        return <p className="flex justify-center ext-center text-xl text-red-500 mb-7 mt-5 font-bold max-sm:max-lg:hidden">Aucun résultat trouvé.</p>;
    }

    const columns = extractColumns(results);
    const data = extractData(results, columns);

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = data.slice(indexOfFirstItem, indexOfLastItem);
    const paginate = (pageNumber) => setCurrentPage(pageNumber);
    return (
        <div className="overflow-x-auto mb-7 mt-5 ">
            <table className="table-auto min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                    <tr>
                        {columns.map((column, index) => (
                            <th key={index} className="px-6 py-3 text-left text-xs font-black bg-blue-200 text-green-800 uppercase tracking-wider">
                                {column}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                    {currentData.map((row, rowIndex) => (
                        <tr key={rowIndex}>
                            {columns.map((column, columnIndex) => (
                                <td key={columnIndex} className="px-6 py-4 whitespace-nowrap">
                                    {row[column]}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
            <div className="mt-4 flex justify-center">
                <button
                    onClick={() => paginate(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-l"
                >
                    Précédent
                </button>
                <button
                    onClick={() => paginate(currentPage + 1)}
                    disabled={indexOfLastItem >= data.length}
                    className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-r"
                >
                    Suivant
                </button>
            </div>
        </div>
    );
}

export default SPARQLResultsTable;