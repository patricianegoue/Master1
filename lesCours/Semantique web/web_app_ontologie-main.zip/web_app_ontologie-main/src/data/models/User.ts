type UserPorps = {
    id?: string,
    username?: string,
    email: string,
    password: string
}

export default UserPorps;