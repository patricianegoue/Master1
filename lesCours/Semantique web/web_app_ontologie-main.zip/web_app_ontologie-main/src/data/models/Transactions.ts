export type Transaction = {
    id: string,
    source: string,
    id_entity_source: string,
    fee: number,
    status: string,
    created_at: string,
}

