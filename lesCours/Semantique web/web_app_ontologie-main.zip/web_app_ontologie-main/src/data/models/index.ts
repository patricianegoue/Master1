export  enum PaymentServiceType {
    MobileMoney = "MobileMoney",
    Bancaire = "Bancaire",
    Cash = "Cash"
}


