# A faire
   -  Ajouter jest pour les test unitaires
   -  Ajouter playground pour les test fonctionnels
   -  Ajouter un read me correct
   -  Ajouter un state manager comme redux ou fait maison (optionnel)
