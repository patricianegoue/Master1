import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SparqlService {

  constructor(
    private _httpCLient: HttpClient
  ) { }

  baseUrl = "http://localhost:3030/HANDON3/";

  ontologiePrefix = `PREFIX food: <http://www.semanticweb.org/emmanuel/ontologies/2024/3/Alimentation-ontology-9#>`;

  requestPrefix = `
  PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
  PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
  PREFIX owl: <http://www.w3.org/2002/07/owl#>`;

  /**
   * -----------------------------------------------------
   * Requests
   * -----------------------------------------------------
   */


  /**
   * Show all the classes and subclasses
   */
  request1(): Observable<any> {
    let query = `PREFIX owl: <http://www.w3.org/2002/07/owl#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    
    SELECT DISTINCT ?class
    WHERE {
      ?class a owl:Class.
    }`;

    const headers = new HttpHeaders()
      .set('Content-Type', 'application/x-www-form-urlencoded');

    const body = new URLSearchParams();
    body.set('query', query);

    return this._httpCLient.post(this.baseUrl, body.toString(), {
      headers: headers,
    });
  }

  /**
   * Give the name of all the foods in ascending and descending order
   * @param mode 
   */
  request2(mode: string): Observable<any> {
    console.log(mode);

    let query = `
    PREFIX foo: <http://filmontology.org/ontology/1.0/>
    PREFIX fo: <http://www.w3.org/1999/XSL/Format#>
    PREFIX owl: <http://www.w3.org/2002/07/owl#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX food: <http://www.semanticweb.org/emmanuel/ontologies/2024/3/Alimentation-ontology-9#>
    SELECT ?foodName
    WHERE {
      ?food rdf:type food:Dish .
      ?food food:hasName ?foodName .
       }
    ORDER BY ` + mode + `(?foodName)`;

    const headers = new HttpHeaders()
      .set('Content-Type', 'application/x-www-form-urlencoded');

    const body = new URLSearchParams();
    body.set('query', query);

    return this._httpCLient.post(this.baseUrl, body.toString(), {
      headers: headers,
    });

  }

}
