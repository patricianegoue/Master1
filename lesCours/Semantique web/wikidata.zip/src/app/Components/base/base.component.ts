import { Component, HostListener } from '@angular/core';
import { SparqlService } from '../Service/sparql.service';
import { ErrorStateMatcher } from '@angular/material/core';
import { FormControl, Validators } from '@angular/forms';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' },
  { position: 2, name: 'Helium', weight: 4.0026, symbol: 'He' },
  { position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li' },
  { position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be' },
  { position: 5, name: 'Boron', weight: 10.811, symbol: 'B' },
  { position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C' },
  { position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N' },
  { position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O' },
  { position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F' },
  { position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
];

@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.css']
})
export class BaseComponent {

  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource = ELEMENT_DATA;

  // request 1 -------------------------------------
  displayedColumnsRequest1: string[] = ['type', 'value'];
  dataSourceRequest1: any[] = [];
  hasResponse1 = false;

  // request 2 -------------------------------------
  displayedColumnsRequest2: string[] = ['name'];
  dataSourceRequest2: any[] = [];
  hasResponse2 = false;
  mode!: string;

  // selected request
  request!: number;

  constructor(
    private _sparqlService: SparqlService
  ) { }

  // Matcher
  matcher = new ErrorStateMatcher();

  // request select form control
  requestFormControl = new FormControl('', [Validators.required]);
  modeFormControl = new FormControl('', [Validators.required]);

  /**
   * Handle on change select value
   * @param value 
   */
  change(value: number) {
    this.request = value;
  }

  /**
   * 
   * @param mode Handle on change mode input
   */
  onChangeMode(mode: string) {
    this.mode = mode;
  }

  clear() {
    this.hasResponse1 = false;
    this.dataSourceRequest1 = [];

    this.hasResponse2 = false;
    this.dataSourceRequest2 = [];
  }

  /**
   * Handle execute funcion
   */
  execute() {

    if (this.requestFormControl.valid) {

      // clear response area
      this.clear();

      switch (this.request.toString()) {
        case '1':
          this.execRequest1();
          break;

        case '2':
          this.execRequest2();
          break;

        default:
          console.log("default");

          break;
      }
    } else {
      console.log("formulaire invalide");

    }
  }

  execRequest1() {
    this.hasResponse1 = false;
    this._sparqlService.request1().subscribe(response => {
      this.dataSourceRequest1 = response.results.bindings;
      this.hasResponse1 = true;
    });
  }

  execRequest2() {
    if (this.modeFormControl.valid) {
      this.hasResponse2 = false;
      this._sparqlService.request2(this.mode).subscribe(response => {
        this.dataSourceRequest2 = response.results.bindings;
        this.hasResponse2 = true;
      });
    }
  }

  ngOnInit() { }

}
